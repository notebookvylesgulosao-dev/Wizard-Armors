package com.example.conjuntosobretudo;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * Bônus do conjunto completo (só valem com as 4 peças equipadas):
 *  +4 corações (= +8 de vida máxima), +30% velocidade, 15% menos repulsão.
 * Os modificadores são transitórios (não são salvos) e reavaliados a cada tick no servidor.
 */
public final class SetBonus {
	private static final ResourceLocation HEALTH_ID = id("set_bonus_health");
	private static final ResourceLocation SPEED_ID = id("set_bonus_speed");
	private static final ResourceLocation KNOCKBACK_ID = id("set_bonus_knockback");

	private SetBonus() {}

	private static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(ConjuntoSobretudo.MOD_ID, path);
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				update(player);
			}
		});
	}

	public static boolean hasFullSet(Player p) {
		return p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.CACHECOL)
				&& p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.SOBRETUDO)
				&& p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.CALCA)
				&& p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.BOTAS);
	}

	private static void update(Player player) {
		boolean full = hasFullSet(player);
		toggle(player, Attributes.MAX_HEALTH, HEALTH_ID, 8.0, Operation.ADD_VALUE, full);
		toggle(player, Attributes.MOVEMENT_SPEED, SPEED_ID, 0.30, Operation.ADD_MULTIPLIED_BASE, full);
		toggle(player, Attributes.KNOCKBACK_RESISTANCE, KNOCKBACK_ID, 0.15, Operation.ADD_VALUE, full);
		if (player.getHealth() > player.getMaxHealth()) {
			player.setHealth(player.getMaxHealth());
		}
	}

	private static void toggle(Player player, Holder<Attribute> attribute, ResourceLocation id,
			double value, Operation op, boolean enable) {
		AttributeInstance inst = player.getAttribute(attribute);
		if (inst == null) return;
		boolean present = inst.hasModifier(id);
		if (enable && !present) {
			inst.addTransientModifier(new AttributeModifier(id, value, op));
		} else if (!enable && present) {
			inst.removeModifier(id);
		}
	}
}
