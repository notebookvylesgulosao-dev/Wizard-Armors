package com.example.conjuntosobretudo;

import java.util.Map;
import java.util.function.Function;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModItems {
	/** Durabilidade base (vanilla: couro 5, ferro 15). Multiplicada por 11/16/15/13 como no jogo base. */
	public static final int BASE_DURABILITY = 10;

	public static final ResourceKey<EquipmentAsset> ASSET_KEY = ResourceKey.create(
			EquipmentAssets.ROOT_ID, ResourceLocation.fromNamespaceAndPath(ConjuntoSobretudo.MOD_ID, "conjunto_sobretudo"));

	/** Armadura por peça: cachecol(HELMET)=1, sobretudo(CHESTPLATE)=2, calça=2, botas=2. */
	public static final ArmorMaterial MATERIAL = new ArmorMaterial(
			BASE_DURABILITY,
			Map.of(
					ArmorType.HELMET, 1,
					ArmorType.CHESTPLATE, 2,
					ArmorType.LEGGINGS, 2,
					ArmorType.BOOTS, 2),
			10,
			SoundEvents.ARMOR_EQUIP_LEATHER,
			0.0F,
			0.0F,
			ItemTags.REPAIRS_LEATHER_ARMOR,
			ASSET_KEY);

	public static final Item CACHECOL = register("cachecol",
			p -> new ArmorItem(MATERIAL, ArmorType.HELMET, p), BASE_DURABILITY * 11);
	public static final Item SOBRETUDO = register("sobretudo",
			p -> new ArmorItem(MATERIAL, ArmorType.CHESTPLATE, p), BASE_DURABILITY * 16);
	public static final Item CALCA = register("calca",
			p -> new ArmorItem(MATERIAL, ArmorType.LEGGINGS, p), BASE_DURABILITY * 15);
	public static final Item BOTAS = register("botas",
			p -> new ArmorItem(MATERIAL, ArmorType.BOOTS, p), BASE_DURABILITY * 13);

	private static Item register(String name, Function<Item.Properties, Item> factory, int durability) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
				ResourceLocation.fromNamespaceAndPath(ConjuntoSobretudo.MOD_ID, name));
		Item item = factory.apply(new Item.Properties().durability(durability).setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
			entries.accept(CACHECOL);
			entries.accept(SOBRETUDO);
			entries.accept(CALCA);
			entries.accept(BOTAS);
		});
	}
}
