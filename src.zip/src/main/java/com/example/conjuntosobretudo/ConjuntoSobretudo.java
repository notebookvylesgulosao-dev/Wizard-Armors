package com.example.conjuntosobretudo;

import net.fabricmc.api.ModInitializer;

public class ConjuntoSobretudo implements ModInitializer {
	public static final String MOD_ID = "conjunto_sobretudo";

	@Override
	public void onInitialize() {
		ModItems.init();
		SetBonus.init();
	}
}
